# 1분기 GWP 탁구 토너먼트 v4

수정 사항:
- 3/4위전도 일반 경기처럼 3판 2선승제로 직접 진행
- 3/4위전에서 실제로 2승이 확정되어 3위가 결정된 뒤에만 최종 팝업 표시
- 결승전과 3/4위전이 모두 완료되어야 1등/2등/3등 축하 팝업 표시

실행:
```bash
cd gwp-pingpong-tournament-v4
python3 -m http.server 8000
```

브라우저:
```bash
http://localhost:8000
```
